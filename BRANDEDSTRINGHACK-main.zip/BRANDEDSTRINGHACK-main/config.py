# TEAM BRANDED ALL COPYRIGHT ©️
class Config:
    API_ID = "28461830"
    API_HASH = "58935dd717d0205b8051e77205f407fb"
    TOKEN = "6683441637:AAEuE8vmywK402hgrSFFLo3loi11cZPSMdQ"
    START_PIC = "https://te.legra.ph/file/e1b4148d7a4cd8b0832d9.jpg"
